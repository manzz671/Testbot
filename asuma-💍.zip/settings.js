//base skyzo 
/*
#asuma v2.8
- • ditss
*/

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

// Settings Bot 
global.DataPc = "120363324022728807@newsletter"
//ini mo di ganti gpp mo ga di ganti gpp jugaa
global.owner = '6285876141367'
global.versi = version
global.footer = '2024 - 2025';
global.namaOwner = "Dapp"
global.namaOwner2 = "`Dapp`"
global.packname = 'asuma toki'
global.botname = 'asuma md'
global.botname2 = 'asuma multi device'

global.pasword = "kontolodon"
global.tempatDB = 'database.json' // Jangan ubah
global.pairing_code = true // Jangan ubah
global.onlygc = false// fungsi hanya untuk group chat
global.onlypc = false // fungsi hanya untuk private chat
global.game = true
// Settings Link / Tautan
global.kirsan = true
global.antispam = true
global.AutoaiPrivat = false
global.linkOwner = "https://wa.me/6285876141367"
global.linkGrup = "https://chat.whatsapp.com/HXb23cWnYxoDD7luHHlSN4"
global.menuStore = "https://files.catbox.moe/cy44re.jpg"
global.pathimg = fs.readFileSync('./source/media/bibir.jpg');
global.inutt = fs.readFileSync('./source/media/dits-pler.jpg');
global.oleng = fs.readFileSync('./source/media/asuma.jpg');
// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 3500
global.delayPushkontak = 6000
global.prefix = "."
// Settings Channel / Saluran
global.linkSaluran = "https://whatsapp.com/channel/0029VamTaL1HwXbAizuCSH0C"
global.idSaluran = "120363324022728807@newsletter"
global.idch = "120363324022728807@newsletter"
global.namaSaluran = "Konan Bot"

global.merchantIdOrderKuota = "-"
global.apiOrderKuota = "-"
global.qrisOrderKuota = "-"
//hiasann
global.sum = ['⛶','❏','⫹⫺']
global.ki = "\`"
global.ka = "\`"
global.emojiw = "🐣"
// Settings Api Digital Ocean
global.apiDigitalOcean = "-"

// Settings Api Digital Ocean
global.apiSimpelBot = "new2025"


// Settings All Payment
global.dana = "Tidak Tersedia"
global.ovo = "Tidak Tersedia"
global.gopay = "Tidak Tersedia"

// Settings Image Url
global.image = {
menu: "https://img101.pixhost.to/images/2/544985517_skyzopedia.jpg", 
reply: "https://files.catbox.moe/85txse.jpg", 
logo: "https://img101.pixhost.to/images/2/544985517_skyzopedia.jpg", 
dana: "https://tmpfiles.org/dl/21386337/tmp.jpg", 
ovo: "https://tmpfiles.org/dl/21386337/tmp.jpg", 
gopay: "https://tmpfiles.org/dl/21386337/tmp.jpg", 
qris: "https://tmpfiles.org/dl/21386337/tmp.jpg"
}

// Settings Api Panel Pterodactyl
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = ""
global.apikey = "" //ptla
global.capikey = "" //ptlc

// Settings Api Panel Pterodactyl Server 2
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "https://"
global.apikeyV2 = "" //ptla
global.capikeyV2 = "" //ptlc

// Settings Api Subdomain
global.subdomain = {
"privatehost.us.kg": {
"zone": "790918217c4add75b7684458518c5836", 
"apitoken": "qYv4NvEN6ZcUIv4dEXihjkmQMwbP_-3Qy_zFlAHv"
}, 
"botwhatsapp.us.kg": {
"zone": "fb1ac418c5564373a56c91d962b30dca", 
"apitoken": "rfQih0XNXiq7AyEuDoLjoFfHX2mhYf_9kddAdKIo"
}, 
"skyzopedia.us.kg": {
"zone": "9e4e70b438a65c1d3e6d0e48b82d79de", 
"apitoken": "odilM9DpvLVPodbPyZwW7UcDKg1aIWsivJc0Vt_o"
}, 
"marketplace.us.kg": {
"zone": "2f33118c3db00b12c38d07cf1c823ed1", 
"apitoken": "6WS_Op6yuPOWcO17NiO-sOP8Vq9tjSAFZyAn82db"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "ZPAXx7CL51PtbGweL2pE3BsI3x0hgTgLuy56iXuo"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "HXVf4soYFM3iiOewHZ6tk6LEnG9f7m7CVhU0EoVz"
}, 
"xyz-store.biz.id": {
"zone": "8ae812c35a94b7bd2da993a777b8b16d", 
"apitoken": "oqZafkd3mSt1bABD9MMTidpCtD9VZdiPTjElVKJB"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "4qOupI-Of-6yNrBaeS1-H0KySuKCd0wS-x0P5XQ4"
}
}
// limit
global.limit = {
	free: 30,
	premium: 9999, 
	vip: 'VIP' 
};
// Message Command 
global.mess = {
	owner: "> *Akses Ditolak*\nFitur ini hanya untuk owner bot!",
	admin: "> *Akses Ditolak*\nFitur ini hanya untuk admin grup!",
	botAdmin: "> *Akses Ditolak*\nFitur ini hanya untuk ketika bot menjadi admin!",
	group: "> *Akses Ditolak*\nFitur ini hanya untuk dalam grup!",
	private: "> *Akses Ditolak*\nFitur ini hanya untuk dalam private chat!",
	prem: "> *Akses Ditolak*\nFitur ini hanya untuk user premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}
// SETTING GAME
global.gamewaktu = 60 // Game waktu
global.bmin = 1000 // Balance minimal 
global.bmax = 3000 // Balance maksimal
global.limit = 15 // Set limit
global.limitawal = {
premium: "Infinity",
free: 8000,
monayawal: 1000
}

// SETTING RPG
global.rpg = { // Bebas ubah value/angka
darahawal: 100,
besiawal: 15,
goldawal: 10,
emeraldawal: 5,
umpanawal: 5,
potionawal: 1
}
// DATABASE GAME
global.suit = {};
global.tictactoe = {};
global.petakbom = {};
global.kuis = {};
global.siapakahaku = {};
global.asahotak = {};
global.susunkata = {};
global.caklontong = {};
global.family100 = {};
global.tebaklirik = {};
global.tebaklagu = {};
global.tebakgambar = {};
global.tebakkimia = {};
global.tebakkata = {};
global.tebakkalimat = {};
global.tebakbendera = {};
global.tebakanime = {};
global.kuismath = {};
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})