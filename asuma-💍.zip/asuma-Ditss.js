"asuma multi device"
//sc ini free🤝

/*
✨ script asuma toki by ditss✨
©powered by ♞𝘿I̶T̶𝗦㐅᭄
my contact 
+6281513607731
my saluran 
https://whatsapp.com/channel/0029VaimJO0E50UaXv9Z1J0L
my res api🔥
- coming soon
thanks to
adiwashing
penyedia res api
yang udah support sc asuma
yang udah pake dari v1 thank🎉
skyzo (base)
*/

